

default['account']['port'] = node['tomcat']['port']
default['account']['version'] = "0.3.6"
default['account']['deploy_dir'] = "/opt/mca-system"
default['account']['url'] = "#{node['deployment_server']['url']}/account-#{node['account']['version']}.zip"
default['account']['db_name'] = "authentication"
