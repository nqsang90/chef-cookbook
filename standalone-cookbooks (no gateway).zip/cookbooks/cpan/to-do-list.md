# to do in future releases
- add cpan cache clean up after install
- add /tmp/local-lib/ clean up by request or with recipe

