default["daemon"]["javaHome"] = "/usr/lib/jvm/default-java"
default["daemon"]["path"] = "/etc/init"

#MCA
default["daemon"]["mca"] = "mca.conf"
default["daemon"]["descriptionMca"] = "mca"
default["daemon"]["authorMca"] = "minhluan"
default["daemon"]["uidMca"] = "root"
default["daemon"]["gidMca"] = "root"
default["daemon"]["mcaSh"] = "/opt/mca/bin/mca.sh"
default["daemon"]["mcaPid"] = "/opt/mca/bin/mca.pid"
