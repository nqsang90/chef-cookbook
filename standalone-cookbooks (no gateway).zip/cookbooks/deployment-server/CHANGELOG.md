# CHANGELOG for deployment-server

This file is used to list changes made in each version of deployment-server.

## 0.1.0:

* Initial release of deployment-server

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
