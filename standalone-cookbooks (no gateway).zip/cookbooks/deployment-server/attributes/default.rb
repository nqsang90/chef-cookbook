


normal['deployment_server']['ip']	= "http://10.120.22.22"
normal['deployment_server']['port'] = "8181"

