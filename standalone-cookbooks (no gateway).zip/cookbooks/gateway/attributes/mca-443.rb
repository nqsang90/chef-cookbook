

default['mca_443']['log_dir'] = node['nginx']['log_dir']
default['mca_443']['location_dir'] = "#{node['nginx']['dir']}/public-location"

