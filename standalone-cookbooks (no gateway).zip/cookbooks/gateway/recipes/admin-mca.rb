
include_recipe "gateway::admin-vs"

nginx_dir = node['nginx']['dir']
servers = search(:node, 'recipes:mca')

if servers.length > 0
	template "#{node['admin_vs']['location_dir']}/admin-mca" do
		content		"admin-mca.erb"
		variables(
			:host_mca => servers[0]['ipaddress'],
			:port_mca => servers[0]['mca']['port']
		)
	notifies :reload, "service[nginx]"
	end
end
