
nginx_dir = node['nginx']['dir']

directory node['admin_vs']['location_dir'] do
	recursive true
end
template "#{nginx_dir}/sites-enabled/admin-vs" do
	content "admin-vs.erb"
	notifies :reload, "service[nginx]"
end

