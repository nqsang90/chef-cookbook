

nginx_dir = node['nginx']['dir']

directory node['mca_443']['location_dir'] do
	recursive true
end
template "#{nginx_dir}/sites-enabled/mca-443" do
	content "mca-443.erb"
	notifies :reload, "service[nginx]"
end
