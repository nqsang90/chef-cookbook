
include_recipe "gateway::mca-443"

nginx_dir = node['nginx']['dir']
servers = search(:node, 'recipes:account')

if servers.length > 0
	template "#{node['mca_443']['location_dir']}/public-account" do
		content		"public-account.erb"
		variables(
			:host_account => servers[0]['ipaddress'],
			:port_account => servers[0]['account']['port']
		)
	notifies :reload, "service[nginx]"
	end
end
