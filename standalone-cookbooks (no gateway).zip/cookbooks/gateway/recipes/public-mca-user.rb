
include_recipe "gateway::mca-443"

nginx_dir = node['nginx']['dir']
servers = search(:node, 'recipes:mcaweb')

if servers.length > 0
	template "#{node['mca_443']['location_dir']}/public-mca-user" do
		content		"public-mca-user.erb"
		variables(
			:host_user => servers[0]['ipaddress'],
			:port_user => servers[0]['user']['port']
		)
	notifies :reload, "service[nginx]"
	end
end
