


## Hadoop Cookbook 3.0.4

* Added `fake_topology` recipe -- hadoop topology script to bin nodes into artificial racks based on cluster/facet/index
