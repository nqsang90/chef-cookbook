# CHANGELOG for id-generator

This file is used to list changes made in each version of id-generator.

## 0.1.0:

* Initial release of id-generator

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
