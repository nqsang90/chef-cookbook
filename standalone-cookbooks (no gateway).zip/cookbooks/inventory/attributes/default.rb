

default['inventory']['port'] = 8181
default['inventory']['version'] = "0.3.10-beta1"
default['inventory']['url'] = "#{node['deployment_server']['url']}/inventory-#{node['inventory']['version']}.zip"
default['inventory']['deploy_dir'] = "/opt/mca-system"
default['inventory']['home'] = "/opt/inventory"

