
default['deployment_server']['url'] = 'http://10.120.0.127:8181'
