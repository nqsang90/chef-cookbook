#
# Cookbook Name:: mca-hr
# Recipe:: default
#
# Copyright 2013, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

package_server = node['deployment_server']['url']
artifact_id = "mca-hr"
version = node['mca_hr']['version']
package = artifact_id + "-" + version + ".zip"
tomcat_dir = node['tomcat']['base']
app_temp_dir = "/tmp/#{artifact_id}"
app_dir = "#{node['mca_hr']['deploy_dir']}/#{artifact_id}"
version_dir = "#{app_dir}/#{version}"
deploy_type = "install"
host_active_mq = node['active_mq']['host']
host_xsecd = "10.120.18.99"

dest_link = "hr"
link_path = "#{tomcat_dir}/webapps/#{dest_link}"

host_user = node['ipaddress']
host_account = node['ipaddress'] 
host_mca = host_user
port_mca = 8484
host_xacct = host_user
port_xacct = 8181

#prepare webapps folder
directory "#{app_dir}/#{version}" do
  recursive true
end


# download
remote_file "#{version_dir}/#{package}" do
 	source "#{node['mca_hr']['url']}"
	checksum node['mca_hr']['checksum']
end

# extract package
execute "extract-package" do
	cwd app_dir+'/'+version
	command "unzip -x #{package}"
	not_if {File.exists?("#{version_dir}/#{artifact_id}")}
end


# config the package

config_dir = "#{version_dir}/#{artifact_id}/WEB-INF"
execute "dos2unix" do
	command "dos2unix #{config_dir}/*.conf"
end

template "#{config_dir}/ctx-service.conf" do
	content "ctx-service.conf.erb"
	variables(
		:host_user => host_user
	)
	notifies :restart, "service[tomcat6]"
end
template "#{config_dir}/service-account.conf" do
	content "service-account.conf.erb"
	variables(
		:host_account => host_account
	)
	notifies :restart, "service[tomcat6]"
end
template "#{config_dir}/service-mca.conf" do
	content "service-mca.conf.erb"
	variables(
		:host_mca => host_mca,
		:port_mca => port_mca
	)
	notifies :restart, "service[tomcat6]"
end
template "#{config_dir}/service-memcached.conf" do
	content "service-memcached.conf.erb"
	notifies :restart, "service[tomcat6]"
end
template "#{config_dir}/service-xacct.conf" do
	content "service-xacct.conf.erb"
	variables(
		:host_xacct => host_xacct,
		:port_xacct => port_xacct
	)
	notifies :restart, "service[tomcat6]"
end
#stop server
#service "tomcat6" do
#	action :stop
#end
# link
link link_path do
	to	"#{app_dir}/#{version}/#{artifact_id}"
	notifies :restart, "service[tomcat6]"
end
# start tomcat server
service "tomcat6" do
	supports :restart => true
	action :enable
end


