

default['order_process']['port'] = 8282
default['order_process']['version'] = "0.2.19"
default['order_process']['url'] = "#{node['deployment_server']['url']}/order-process-#{node['order_process']['version']}.zip"
default['order_process']['deploy_dir'] = "/opt/mca-system"
default['order_process']['home'] = "/opt/order-process"
default['order_process']['checksum'] = "9533c16787eb3812658a8db224a5e5460ed9095b372b454bdc417571fbb95a4d"
