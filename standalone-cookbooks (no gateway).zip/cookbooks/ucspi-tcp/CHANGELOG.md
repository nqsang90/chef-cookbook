## v1.0.2:

This release adds test kitchen support.

### Bug

- [COOK-2888]: Add name to metadata

## v1.0.0:

- Initial public release
