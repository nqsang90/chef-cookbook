
default['xacct']['port'] = 8585
default['xacct']['version'] = "0.3.5-beta2"
default['xacct']['url'] = "#{node['deployment_server']['url']}/xacct-#{node['xacct']['version']}.zip"
default['xacct']['deploy_dir'] = "/opt/mca-system"
default['xacct']['home'] = "/opt/xacct"

